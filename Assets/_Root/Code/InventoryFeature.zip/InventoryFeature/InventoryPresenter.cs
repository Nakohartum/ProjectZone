﻿using System.Linq;
using _Root.Code.InputFeature;
using Unity.VisualScripting;

namespace _Root.Code.InventoryFeature
{
    public class InventoryPresenter
    {
        private InventoryView _view;
        private InventoryModel _inventoryModel;
        private InputController _inputController;

        public InventoryPresenter(InventoryView view, InputController inputController, InventoryModel inventoryModel)
        {
            _view = view;
            _inputController = inputController;
            _inventoryModel = inventoryModel;
            _inputController.InventoryButton.onClick.AddListener(OpenInventory);
            _view.CloseInventoryButton.onClick.AddListener(CloseInventory);
        }

        public void TryAddItem(InventoryItem item)
        {
            var inventoryItem = _inventoryModel.Items.FirstOrDefault(q => q.Name == item.Name);
            if (inventoryItem != null)
            {
                inventoryItem.AddStack();
                var inventoryItemView = _view.Slots.FirstOrDefault(q => q.Name.text == inventoryItem.Name);
                inventoryItemView.SetInformation(inventoryItem.Icon, inventoryItem.Name, inventoryItem.IsStackable? inventoryItem.CurrentStack.ToString() : "");
            }
            else
            {
                var inventoryItemView = _view.Slots.FirstOrDefault(q=> !q.Reserved);
                if (inventoryItemView != null)
                {
                    _inventoryModel.AddItem(item);
                    inventoryItemView.SetInformation(item.Icon, item.Name, item.IsStackable? item.CurrentStack.ToString() : "");
                }
            }
        }

        public void CloseInventory()
        {
            _view.gameObject.SetActive(false);
        }

        public void OpenInventory()
        {
            _view.gameObject.SetActive(true);
        }
    }
}