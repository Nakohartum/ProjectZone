﻿using UnityEngine;

namespace _Root.Code.InventoryFeature
{
    public class InventoryItem
    {
        public Sprite Icon { get; private set; }
        public string Name { get; private set; }
        public bool IsStackable { get; private set; }
        public int StackSize { get; private set; }
        public int CurrentStack {get; private set;}

        public InventoryItem(Sprite icon, string name, bool isStackable, int stackSize, int currentStack)
        {
            Icon = icon;
            Name = name;
            IsStackable = isStackable;
            StackSize = stackSize;
            CurrentStack = currentStack;
        }

        public void AddStack()
        {
            if (IsStackable)
            {
                CurrentStack++;
            }
        }
    }
}