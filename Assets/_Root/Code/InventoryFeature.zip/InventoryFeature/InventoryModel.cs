﻿using System.Collections.Generic;

namespace _Root.Code.InventoryFeature
{
    public class InventoryModel
    {
        public List<InventoryItem> Items { get; set; }

        public InventoryModel()
        {
            Items = new List<InventoryItem>();
        }

        public void AddItem(InventoryItem item)
        {
            Items.Add(item);
        }
    }
}